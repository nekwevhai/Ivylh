
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import social from "./assets/social.png";

export default function Landing() {
  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center text-center">
      <motion.img
        src={social}
        className="w-3/4 max-w-xl mx-auto"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1 }}
      />
      <h1 className="text-6xl font-bold text-pink-500 mt-4">BOOM BOOM</h1>
      <p className="text-xl text-pink-300 mt-2">The ultimate neon puzzle explosion.</p>
      <Link to="/game">
        <button className="mt-6 px-8 py-4 bg-pink-600 rounded-full text-white text-xl font-semibold">
          PLAY NOW
        </button>
      </Link>
    </div>
  );
}
